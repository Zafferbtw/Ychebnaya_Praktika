this folder contains the c++ core library + console + tests.
