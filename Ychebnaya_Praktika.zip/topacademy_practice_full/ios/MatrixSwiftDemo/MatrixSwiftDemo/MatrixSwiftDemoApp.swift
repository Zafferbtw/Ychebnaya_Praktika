
import SwiftUI

@main
struct MatrixSwiftDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
